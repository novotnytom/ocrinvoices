import React from 'react';

interface TopPanelProps {
  profiles: string[];
  selectedProfile: string;
  setSelectedProfile: (v: string) => void;
  batchName: string;
  setBatchName: (v: string) => void;
  onSave: () => void;
  isEditing: boolean;
}

export default function TopPanel({
  profiles,
  selectedProfile,
  setSelectedProfile,
  batchName,
  setBatchName,
  onSave,
  isEditing
}: TopPanelProps) {
  return (
    <div className="bg-gray-100 p-4 rounded space-y-2">
      <h1 className="text-lg font-semibold">
        {isEditing ? 'Editing Invoice Batch' : 'Creating New Invoice Batch'}
      </h1>
      <div className="flex gap-4 items-center">
        <select
          value={selectedProfile}
          onChange={e => setSelectedProfile(e.target.value)}
          className="border p-2 w-48"
        >
          <option value="">-- Select Profile --</option>
          {profiles.map(name => (
            <option key={name} value={name}>{name}</option>
          ))}
        </select>
        <input
          type="text"
          value={batchName}
          onChange={e => setBatchName(e.target.value)}
          placeholder="Batch name"
          className="border p-2 flex-1"
        />
        <button
          onClick={onSave}
          className="bg-purple-600 text-white px-4 py-2 rounded"
        >
          Save
        </button>
      </div>
    </div>
  );
}
