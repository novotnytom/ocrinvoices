import { useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import axios from "axios";
import {
    DndContext,
    closestCenter,
    PointerSensor,
    useSensor,
    useSensors,
} from "@dnd-kit/core";
import {
    arrayMove,
    SortableContext,
    sortableKeyboardCoordinates,
    verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { restrictToVerticalAxis } from "@dnd-kit/modifiers";
import { SortableItem } from "../components/invcgeneraloverview/SortableItem";

interface OverviewInvoice {
    id: string;
    batch_name: string;
    invoice_date: string;
    invoice_number: string;
    template_used: string;
    total_value: number;
    accounting_info?: string;
    company_id?: string;
    selected: boolean;
    order: number;
}

export function GeneralOverviewPage() {
    const [invoices, setInvoices] = useState<OverviewInvoice[]>([]);
    const [selectAll, setSelectAll] = useState(false);
    const [defaultAccountingInfo, setDefaultAccountingInfo] = useState("");
    const [defaultCompanyId, setDefaultCompanyId] = useState("");

    const sensors = useSensors(
        useSensor(PointerSensor),
    );

    useEffect(() => {
        fetchInvoices();
    }, []);

    const fetchInvoices = async () => {
        const response = await axios.get("http://localhost:8000/overview/list_invoices");
        setInvoices(response.data);
    };

    const toggleSelectAll = () => {
        const newSelectAll = !selectAll;
        setSelectAll(newSelectAll);
        setInvoices((prev) =>
            prev.map((inv) => ({ ...inv, selected: newSelectAll }))
        );
    };

    const handleCheckboxChange = (id: string) => {
        setInvoices((prev) =>
            prev.map((inv) =>
                inv.id === id ? { ...inv, selected: !inv.selected } : inv
            )
        );
    };

    const handleInputChange = (id: string, field: keyof OverviewInvoice, value: string) => {
        setInvoices((prev) =>
            prev.map((inv) =>
                inv.id === id ? { ...inv, [field]: value } : inv
            )
        );
    };

    const handleDragEnd = async (event: any) => {
        const { active, over } = event;
        if (active.id !== over.id) {
            setInvoices((prev) => {
                const oldIndex = prev.findIndex((i) => i.id === active.id);
                const newIndex = prev.findIndex((i) => i.id === over.id);
                const newInvoices = arrayMove(prev, oldIndex, newIndex);
                newInvoices.forEach((inv, idx) => (inv.order = idx));
                newInvoices.forEach(async (inv) => {
                    await axios.patch(`http://localhost:8000/overview/update_invoice/${inv.id}`, { order: inv.order });
                });
                return newInvoices;
            });
        }
    };

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">General Overview</h1>

            <div className="mb-6 flex gap-4">
                <div>
                    <label className="block mb-1 text-sm font-medium">Default Accounting Info</label>
                    <Input
                        value={defaultAccountingInfo}
                        onChange={(e) => setDefaultAccountingInfo(e.target.value)}
                        placeholder="Enter default accounting info"
                    />
                </div>
                <div>
                    <label className="block mb-1 text-sm font-medium">Default Company ID</label>
                    <Input
                        value={defaultCompanyId}
                        onChange={(e) => setDefaultCompanyId(e.target.value)}
                        placeholder="Enter default company ID"
                    />
                </div>
            </div>

            <div className="border rounded-md">
                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd} modifiers={[restrictToVerticalAxis]}>
                    <SortableContext items={invoices.map((inv) => inv.id)} strategy={verticalListSortingStrategy}>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>
                                        <Checkbox checked={selectAll} onCheckedChange={toggleSelectAll} />
                                    </TableHead>
                                    <TableHead>Batch Name</TableHead>
                                    <TableHead>Invoice Date</TableHead>
                                    <TableHead>Invoice Number</TableHead>
                                    <TableHead>Template Used</TableHead>
                                    <TableHead>Total Value</TableHead>
                                    <TableHead>Accounting Info</TableHead>
                                    <TableHead>Company ID</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {invoices.map((invoice) => (
                                    <TableRow>
                                        <TableCell>
                                            <Checkbox
                                                checked={invoice.selected}
                                                onCheckedChange={() => handleCheckboxChange(invoice.id)}
                                            />
                                        </TableCell>
                                        <TableCell>{invoice.batch_name}</TableCell>
                                        <TableCell>{invoice.invoice_date}</TableCell>
                                        <TableCell>{invoice.invoice_number}</TableCell>
                                        <TableCell>{invoice.template_used}</TableCell>
                                        <TableCell>{invoice.total_value.toFixed(2)}</TableCell>
                                        <TableCell>
                                            <Input
                                                value={invoice.accounting_info ?? defaultAccountingInfo}
                                                onChange={(e) => handleInputChange(invoice.id, "accounting_info", e.target.value)}
                                            />
                                        </TableCell>
                                        <TableCell>
                                            <Input
                                                value={invoice.company_id ?? defaultCompanyId}
                                                onChange={(e) => handleInputChange(invoice.id, "company_id", e.target.value)}
                                            />
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </SortableContext>
                </DndContext>
            </div>

            <div className="mt-6">
                <Button>Export Selected to FlexiBee</Button>
            </div>
        </div>
    );
}

export default GeneralOverviewPage;
