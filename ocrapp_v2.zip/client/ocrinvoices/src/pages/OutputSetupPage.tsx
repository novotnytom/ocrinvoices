export default function OutputSetupPage() {
    return <h1>Setup Output – Define Structure</h1>;
  }
  