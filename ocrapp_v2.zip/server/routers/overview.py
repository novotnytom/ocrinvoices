from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from fastapi.responses import Response
import os
import json
import uuid
import xml.etree.ElementTree as ET

router = APIRouter()

overview_path = "data/overview"
os.makedirs(overview_path, exist_ok=True)

class OverviewInvoice(BaseModel):
    id: str
    batch_name: str
    invoice_date: str
    invoice_number: str
    template_used: str
    total_value: float
    accounting_info: Optional[str] = None
    company_id: Optional[str] = None
    selected: bool = True
    order: int

@router.post("/overview/add_batch")
def add_batch(invoices: List[OverviewInvoice]):
    for inv in invoices:
        file_path = os.path.join(overview_path, f"{inv.id}.json")
        with open(file_path, 'w') as f:
            json.dump(inv.dict(), f)
    return {"status": "Batch added", "count": len(invoices)}

@router.get("/overview/list_invoices", response_model=List[OverviewInvoice])
def list_invoices():
    invoices = []
    for filename in os.listdir(overview_path):
        if filename.endswith(".json"):
            with open(os.path.join(overview_path, filename), 'r') as f:
                data = json.load(f)
                invoices.append(OverviewInvoice(**data))
    invoices.sort(key=lambda x: x.order)
    return invoices

@router.patch("/overview/update_invoice/{invoice_id}")
def update_invoice(invoice_id: str, updated_fields: dict):
    file_path = os.path.join(overview_path, f"{invoice_id}.json")
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Invoice not found")
    with open(file_path, 'r') as f:
        data = json.load(f)
    data.update(updated_fields)
    with open(file_path, 'w') as f:
        json.dump(data, f)
    return {"status": "Invoice updated"}

class ExportRequest(BaseModel):
    ids: List[str]

@router.post("/overview/export_selected")
def export_selected(req: ExportRequest):
    root = ET.Element("Invoices")
    for invoice_id in req.ids:
        file_path = os.path.join(overview_path, f"{invoice_id}.json")
        if not os.path.exists(file_path):
            continue
        with open(file_path, 'r') as f:
            data = json.load(f)

        inv_elem = ET.SubElement(root, "Invoice")
        ET.SubElement(inv_elem, "InvoiceNumber").text = data.get("invoice_number")
        ET.SubElement(inv_elem, "InvoiceDate").text = data.get("invoice_date")
        ET.SubElement(inv_elem, "BatchName").text = data.get("batch_name")
        ET.SubElement(inv_elem, "TemplateUsed").text = data.get("template_used")
        ET.SubElement(inv_elem, "TotalValue").text = str(data.get("total_value"))
        ET.SubElement(inv_elem, "AccountingInfo").text = data.get("accounting_info", "")
        ET.SubElement(inv_elem, "CompanyId").text = data.get("company_id", "")

    xml_str = ET.tostring(root, encoding='utf-8')
    return Response(content=xml_str, media_type="application/xml")
